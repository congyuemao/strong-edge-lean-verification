# PACKING20 文献先例审查

审查日期：2026-10-10（Australia/Sydney）。本文件是有范围限制的先例审查，不是原创性证明，也不是期刊论文证明的 Lean 形式化。

## 结论与证据边界

已确认完整原边集的 20 倍保证存在既有先例；21 色定理、私有冲突邻域交换与双重计数也有明确先例。本轮检索没有确认一项已发表、适用于所有最大度至多四简单图的任意候选边集 20 倍定理，或足以直接覆盖它的分数强色数至多 20 定理。**不能据此宣称原创。**

最重要的未完成项：Joos–Nguyen 2016 期刊正文未取得，故其证明中是否包含可推广到任意候选集／加权版本的论断，**未核查正文，尚不确定**。已查阅两位作者各自 2014 年预印本的定理及归纳证明路线，但它们不是双作者期刊终稿，不能用其编号冒充期刊编号。

## 1. Joos–Nguyen：已确认完整边集先例，终稿范围未完全核查

Felix Joos, Viet Hang Nguyen, *Induced Matchings in Graphs of Degree at Most 4*, SIAM J. Discrete Math. 30(1), 154–165 (2016), DOI [10.1137/140986980](https://epubs.siam.org/doi/10.1137/140986980)。出版商摘要确认：最大度至多四、无孤立点且无双点五圈分量时，νₛ(G)≥n(G)/9；由此得到该类图的 m(G)/18 界，以及一般最大度四图的 m(G)/20 界。

访问 DOI 正文、`/doi/pdf/`、`/doi/epdf/` 和下载入口时，只获得摘要／购买入口、摘要重定向或抓取失败；又核查了 [Joos 的海德堡大学作者主页](https://web.ifi.uni-heidelberg.de/tcs/joos)，第16项列有联合期刊文献，但该项没有提供全文链接。**期刊定理编号不明，不作猜测。**

可核查的作者预印本分别为：

| 来源 | 确切编号与前提 | 结论与证据范围 |
|---|---|---|
| [Joos, arXiv:1407.8336v1](https://arxiv.org/html/1407.8336v1) | Theorem 1；Δ(G)≤4；i(G) 为孤立点数，n₅(G) 为双点五圈分量数 | νₛ(G)≥(n(G)−i(G)−n₅(G))/9。第 2 节通过标记一或两条边、删去其闭邻域并递归扩张匹配证明。 |
| [Nguyen, arXiv:1407.7604v1](https://arxiv.org/pdf/1407.7604) | Theorem 1′；Δ(G)≤4，且无 C₂,₅ 分量 | νₛ(G)≥(n(G)−i(G))/9。采用最小反例及局部删点归约。采用 1′ 以避免 Theorem 1 的连通图表述在单孤立点上的边界问题。 |

推导（本审计）：n−i≥m/2，且 n₅≤(n−i)/10，因此 Joos 预印本的 Theorem 1 给出 νₛ≥(n−i)/10≥m/20；n₅=0 时给出 m/18。这确认 `F=E(G)` 的先例。

不能直接把 G 换成只保留 F 的图：删边可能消除 F 两条边之间的冲突见证。四点路径的首尾两边即为反例：在只保留首尾边的图中可同时选，在原路径中不能。预印本归约允许标记任意原边；要得到候选集版本，必须保证每次加入的边在 F 中，并重新建立计数不变量。未发现该迁移的现成证明；这不是“不可能迁移”的结论。

## 2. Huang–Santana–Yu：期刊 Theorem 2 是 21 色

Mingfang Huang, Michael Santana, Gexin Yu, *Strong Chromatic Index of Graphs With Maximum Degree Four*, EJC 25(3), P3.31 (2018), DOI [10.37236/7016](https://www.combinatorics.org/ojs/index.php/eljc/article/view/v25i3p31)。已读取[期刊 PDF 正文](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v25i3p31/pdf)。**Theorem 2（印刷页 2）**：最大度四图的强色指数至多 21。证明在第 4 节完成，部分结构引理的证明在第 5 节；讨论的是完整图中的强边染色。

推导（本审计）：把 21 个色类与任意 F 相交，至少一个交集大小≥|F|/21，并仍为完整 G 中的诱导匹配。故该定理给出 Hall ratio≤21，不能直接给出≤20。小于四的度数可通过加入不交的度四分量再限制回原图覆盖。不能将证明中的“至多 20 个已用邻色”误读为最终总色数 20。

## 3. Steiner：Hall ratio 与分数色数必须区分

Raphael Steiner, *Fractional Chromatic Number Vs. Hall Ratio*, Combinatorica 45, article 37 (2025), DOI [10.1007/s00493-025-00164-0](https://link.springer.com/article/10.1007/s00493-025-00164-0)。已读取出版商全文的定义、Theorems 1.1、1.3、1.5 及相关证明说明。

第 1 节公式 (M) 将 χ_f 表为任意非负点权下总权重与最大独立集权重之比的上确界；限制为 0/1 权重得到 Hall ratio，因而 ρ≤χ_f≤χ。Theorem 1.5 给出对每个 δ>0、足够大的 n，存在 Hall ratio≤4+δ 而分数色数随 n 无界增长的图，并附有对子图度数权的独立集保证。该定理不限定为最大度四图的平方线图。

推导（本审计）：取 H=L(G)²。对全部 F⊆E(G) 的本项目命题恰好是 ρ(H)≤20；空 F 单独平凡处理。若已有 χ_f(H)≤20，则给每条 F 边权 1、其余权 0，即可推出本命题。反向推导对一般图不成立；本项目也未证明反向推导在这一特殊图类成立。

## 4. 私有邻域与局部交换已有方法先例

Maximilian Fürst, Marilena Leichter, Dieter Rautenbach, *Locally Searching for Large Induced Matchings*, Theoretical Computer Science 720, 64–72 (2018), DOI [10.1016/j.tcs.2018.02.006](https://www.sciencedirect.com/science/article/pii/S0304397518300835)。已读取[作者预印本 arXiv:1708.02028v1](https://arxiv.org/html/1708.02028v1) 的定义、Local Search、Lemma 1、Theorem 2、Corollary 3 及证明；以下编号属于该预印本。

该算法使用添加一条边、用两条边替换一条边的改进。其式 (2) 表明私有冲突边必须两两冲突；Theorem 2(ii) 的原文设置为最大度 d≥3、M 由 Local Search 产生，并假设每条边满足 c_G(xy)≥f、n_xy≥g，给出

`|M| ≥ m(G) / (3d² − d − f − ((d+6)/2)g)`，

其中 c_G 是含自身的冲突边数，n_xy=|N(x)∩N(y)|。证明使用私有冲突边计数和双重计数；Corollary 3 对 d-正则图给出近似算法，其证明取 f=(3d²−d)/2、g=0 并结合贪心预处理。

在该推论中代入 d=4 得 f=22，即其证明给出4-正则图完整边集 m/22，不能直接覆盖任意 F 的 20 倍结论。其无四圈等更强结果另有图类限制。**“私有团交换／双重计数”不可作为全新方法宣称。** 本次形式化的次级度数最小化及五档阈值如何与全部既有局部引理比较，仍需进一步学术审查。

## 5. 已核查的通用分数界不足以覆盖 20

Małgorzata Śleszyńska-Nowak, [*Clique number of the square of a line graph*, arXiv:1504.06585](https://arxiv.org/pdf/1504.06585)。正文 **Theorem 7** 对简单图给出分数强色指数≤1.75Δ²。其证明结合 Theorem 5 的团数界与分数版 Reed 界，还给出≤1.75Δ²−Δ+0.5；Δ=4 时分别是 28 和 24.5，均不推出 20。这里引用确已读取的预印本编号，不另行猜测期刊编号或 DOI。

另检索到二分图分数强色数与排除完全图 minor 的相关论文。它们有额外图类前提，不能直接用于本任务全部 Δ≤4 图。未将摘要检索结果升格为覆盖本结果的先例。

## 6. 检索范围、无效推导与剩余事项

使用了任务指定的 `Hall ratio squared line graphs maximum degree four`、`induced matching every subset of edges graph degree 4`、`hereditary induced matching bound`、`private neighbourhood local improvements strong clique degree thresholds`，并补充精确标题、DOI、`fractional strong chromatic index`、`Locally Searching for Large Induced Matchings` 等检索。搜索命中只是发现线索；以上数学判断仅采用出版商、作者预印本等原始来源。

以下推导均未获支持：完整边集 20 倍 ⇒ 固定原图中每个候选集 20 倍；21 色 ⇒20 倍；团数≤20 ⇒ Hall ratio≤20；Hall ratio≤20 ⇒分数强色数≤20；一次 Lean 验收 ⇒整数强边二十色猜想成立；没有搜索命中 ⇒原创。

尚需：取得并检查 Joos–Nguyen 2016 终稿，核查其全部加权／候选集相关陈述；继续检索并核对局部分数染色及局部搜索改进文献。当前证据足以确认若干既有结果和方法联系，**不足以签署学术原创性结论**。没有联系作者、购买论文、投稿或发布任何内容。
