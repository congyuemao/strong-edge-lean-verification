# Strong-edge packing: Lean formalisation

C4 and the `high24` and `high23` clique bounds are complete. In every finite
simple graph of maximum degree four, every original edge has full conflict
degree at most 24. Every conflict clique whose members all have full conflict
degree at least 23 has at most **16** edges; at threshold 24 the proved bound
is **13**, which supplies the required `high24 ≤15` field.
The unconditional 20-packing theorem is **not yet proved**: `high20`, `high21`,
and `high22` remain open in this formalisation.

Verified on 9 October 2026: the full build passed (1,136 jobs) and all 94 audited
theorems use only `propext`, `Classical.choice`, and `Quot.sound`. No proof gaps
or custom axioms occur in these dependency closures. Current evidence is in
`verification/high23-build.log` and `verification/high23-axioms.log`.
All previous logs and checkpoint archives are preserved. See the
[high23 handoff](HIGH23_HANDOFF.md) for this stage's 43 new theorem names,
exact exported signatures, checks, and remaining work. The earlier
[high24 handoff](verification/high24-handoff.md) and
[C4 report](verification/NEXT_STAGE_REPORT.md) records the preceding stage.

## Verified mathematical core

- `Basic.lean`: all-original-edge conflicts and the private-clique exchange.
- `Conflict.lean`: independence/induced-matching equivalence and the inequality
  from candidate conflict degree to full conflict degree.
- `PrivateExchange.lean`: existence of a maximum independent set with minimum
  ambient degree sum, and the degree-monotonicity exchange.
- `DoubleCount.lean`: closed-neighbourhood incidence counting and
  `2 * Fintype.card W ≤ ∑ v ∈ M, (degree v + 1 + privateCard v)`;
  an explicit local bound implies packing, including the conditional 20 bound.
- `Tests.lean`: in the path 0-1-2-3 the outer edges conflict; after removing 1-2
  they do not. Restricting candidates retains the original conflict.
- `Bounds/ConflictDegree.lean`: an incidence cover proves
  `conflict_degree_le_24` directly from the original maximum-degree-four bound.
- `Bounds/ConflictRigidity.lean`: equality at 24 forces both endpoints and their
  six other neighbours to have degree four; those six vertices are independent,
  neither endpoint lies in a triangle, and the fixed edge lies in no four-cycle.
- `MinimalPacking.lean`: a separate, weaker interface suffices for 20-packing;
  the degree-24 clique bound need only be 15. The new original-edge wrapper
  supplies C4 automatically and retains the five clique bounds explicitly.
- `Bounds/High24.lean`: mixed branches cannot contain a fork; each side has
  at most three external clique edges, giving `high24_clique_card_le_thirteen`
  and its `high24_clique_card_le_fifteen` corollary.
- `High24Packing.lean`: constructs `MinimalCliqueBounds20` using the proved
  high24 bound and four explicit lower-threshold hypotheses, then exports the
  corresponding original-edge packing theorem.
- `Bounds/EdgeCounting.lean`: exact incidence counting, with one duplicate
  per internal edge, and clique bounds from selected incidence degrees.
- `Bounds/High23Local.lean`: a high23 edge has degree-four endpoints, lies in
  no triangle, and lies in at most one four-cycle.
- `Bounds/High23Support.lean`: root-neighbour types have size at most two;
  double types sharing a selected root label belong to the same vertex.
- `Bounds/High23Outer.lean`: at most two clique edges lie outside a root's
  closed neighbourhood when it has at least three selected incident edges;
  selected incidence degrees at most three imply a clique bound of 14.
- `Bounds/High23Four.lean`: a four-edge root star has at most six singleton-type
  edges and at most four multiple-type edges meeting its neighbourhood.
- `Bounds/High23.lean`: combines the support-degree cases to prove
  `high23_clique_card_le_sixteen` from the original degree bound alone.
- `High23Packing.lean`: supplies both high23 and high24 to the unchanged minimal
  record, leaving only high20, high21, and high22 explicit in the packing wrapper.

`Packing.lean` extends the conditional result to every candidate subset and
states it in terms of original edges. It passed the full build and axiom audit.
Both threshold records and all eleven earlier mathematical source modules
are unchanged. No claim is made that a maximum-degree-four original graph has
yet been shown to satisfy either threshold record without the three remaining
clique hypotheses. The original record's stronger high24 bound 7 is still open.

## Pinned environment

- Lean: `leanprover/lean4:v4.35.0-rc4`
- Lean compiler commit: `c29b6dda4f7c20e3eeaa717c4e565663c5cfa364`
- mathlib: `49fd9dee36e7bbf345fe7981d2de6aeeb591f75b`
- Dependency lockfile: `lake-manifest.json`

The Windows compiler was downloaded from the official Lean release and verified
against SHA-256 `549c0d70f58346be61d9353b5ff8b3d89430b49184d1833244ba2f3afca3dabd`.
It lives beside this project in `../.tools/lean-4.35.0-rc4-windows`; `lean.ps1`
uses it when available, otherwise it uses Lake from PATH. Compiler binaries,
dependency checkouts, and caches are excluded from the source archive.

## Reproduce

In this project's Windows PowerShell directory:

```powershell
.\lean.ps1 build
.\lean.ps1 env lean StrongEdge/Audit.lean
```

With Lean/elan already installed on another system:

```sh
lake exe cache get Mathlib.Combinatorics.SimpleGraph.Clique Mathlib.Combinatorics.SimpleGraph.LineGraph Mathlib.Tactic.ByContra Mathlib.Tactic.Linarith Mathlib.Tactic.Tauto Mathlib.Algebra.Order.BigOperators.Group.Finset
lake build
lake env lean StrongEdge/Audit.lean
```

Keep the supplied lockfile; `lake update` is not needed for an ordinary rebuild.
The first build may need network access to materialize locked dependencies.

## Checked endpoint

The current endpoint is
`StrongEdge.induced_matching_packing20_of_high20_high21_high22`.
It takes the original degree bound `hΔ` and exactly three explicit clique-bound
parameters, with the meanings in the table below. It constructs the old `hb`
record by supplying `high23_clique_card_le_sixteen` and
`high24_clique_card_le_fifteen` automatically and calls the
preserved `StrongEdge.induced_matching_packing20_of_minimal_clique_bounds`:

```lean
(hΔ : ∀ x, G.degree x ≤ 4)
(hb : MinimalCliqueBounds20 (conflictGraph G)) (F : Finset G.edgeSet) :
  ∃ M ⊆ F, IsInducedMatching G (M : Set G.edgeSet) ∧ F.card ≤ 20 * M.card
```

The finite-vertex and decidability instances are shown in full in the axiom log.
The old wrapper still takes `hb`; the new wrapper discharges its high23 and
high24 fields and retains high20–high22 explicitly. The old
`induced_matching_packing20_of_thresholds` is also preserved and audited.
The private-clique, degree-exchange and double-counting proofs have no such
structural premises. Empty graphs and empty candidate sets require no exception.

The source scan found no `sorry`, `admit`, `axiom`, `constant`, `unsafe`, or
`native_decide` tokens in the twenty project Lean files. The axiom audit, rather than that textual
scan alone, checks the exported proof dependencies. Source/configuration SHA-256
fingerprints are saved in `verification/high23-source-sha256.json`.
Earlier source manifests are retained as historical snapshots.

## Still required

For every clique `Q` in the **full** conflict graph, `MinimalCliqueBounds20`
requires the following five facts. The last two have now been proved universally.

| Field | Lower bound on every member's full conflict degree | Required bound on `Q.card` | Status |
|---|---:|---:|---|
| `high20` | 20 | 19 | Open |
| `high21` | 21 | 18 | Open |
| `high22` | 22 | 17 | Open |
| `high23` | 23 | 16 | Proved |
| `high24` | 24 | 15 | Proved, with stronger bound 13 |

Next, formalise `high22`, followed by `high21` and `high20`.
Discharging the three open fields yields the unconditional theorem through the
new wrapper. The original
record additionally includes maximum degree 24 (now proved for these conflict
graphs) and uses the stronger degree-24 clique bound 7. The 19.5 strengthening
remains a later, separate goal.

The current result is conditional; it proves neither unconditional 20-packing
nor integer strong-edge 20-colourability. The input handoff is retained in
`LEAN_20_PACKING_HANDOFF.md`; its original uncompiled-starter descriptions are
historical. This README and the saved build/audit logs describe the current code.

## Mathematical source

[Research proof at the supplied commit](https://github.com/congyuemao/strong-edge-colouring-research/blob/3a95c4a9c44475196c42b6eab4749c487d15d59b/research/packing_private_cliques.md).

[High23 proof at the same commit](https://github.com/congyuemao/strong-edge-colouring-research/blob/3a95c4a9c44475196c42b6eab4749c487d15d59b/research/high_conflict_23_improved.md).
This implementation uses a uniform outer-edge bound of two to obtain the
required 16; the optional strengthening to 15 is not exported.
