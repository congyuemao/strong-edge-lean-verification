# Strong-edge packing: Lean formalisation

C4 and the `high24`, `high23`, `high22`, and `high21` clique bounds are complete.
In every finite simple graph of original maximum degree four, full conflict degree
is at most 24. The verified clique bounds are 13 at threshold 24, 16 at threshold 23,
17 at threshold 22, and **18 at threshold 21**.

Verified on 10 October 2026 (Australia/Sydney): the full build passed with
**1,162 jobs**, without warnings, and all **192 audited declarations** use only
`propext`, `Classical.choice`, and `Quot.sound`. The high21 stage adds 47 theorems
in nine modules. All 26 earlier mathematical modules remain byte-for-byte unchanged.

The packing theorem remains **conditional on high20**, the only remaining structural
premise. Unconditional 20-packing, the 19.5 strengthening, and integer strong-edge
20-colourability are not proved. The new threshold-free subcubic bound is 18;
the stronger bound 17 and optional high21 bound 17 have not been claimed.

See [C5_HIGH21_VERIFIED_HANDOFF.md](C5_HIGH21_VERIFIED_HANDOFF.md) for complete theorem
types, proof explanations, preservation checks and reproduction commands. Evidence:
[build](verification/high21-build.log), [audit](verification/high21-axioms.log),
[source checks](verification/high21-source-checks.json), and
[checkpoint](../strong_edge_lean_high21_checkpoint.zip).

Earlier handoffs remain intact: [high22](HIGH22_HANDOFF.md), [high23](HIGH23_HANDOFF.md),
[high24](verification/high24-handoff.md), and [C4](verification/NEXT_STAGE_REPORT.md).

## Verified mathematical core

- `Basic.lean`: all-original-edge conflicts and the private-clique exchange.
- `Conflict.lean`: independence/induced-matching equivalence and the inequality
  from candidate conflict degree to full conflict degree.
- `PrivateExchange.lean`: existence of a maximum independent set with minimum
  ambient degree sum, and the degree-monotonicity exchange.
- `DoubleCount.lean`: closed-neighbourhood incidence counting and
  `2 * Fintype.card W ≤ ∑ v ∈ M, (degree v + 1 + privateCard v)`;
  an explicit local bound implies packing, including the conditional 20 bound.
- `Tests.lean`: in the path 0-1-2-3 the outer edges conflict; after removing 1-2
  they do not. Restricting candidates retains the original conflict.
- `Bounds/ConflictDegree.lean`: an incidence cover proves
  `conflict_degree_le_24` directly from the original maximum-degree-four bound.
- `Bounds/ConflictRigidity.lean`: equality at 24 forces both endpoints and their
  six other neighbours to have degree four; those six vertices are independent,
  neither endpoint lies in a triangle, and the fixed edge lies in no four-cycle.
- `MinimalPacking.lean`: a separate, weaker interface suffices for 20-packing;
  the degree-24 clique bound need only be 15. The new original-edge wrapper
  supplies C4 automatically and retains the five clique bounds explicitly.
- `Bounds/High24.lean`: mixed branches cannot contain a fork; each side has
  at most three external clique edges, giving `high24_clique_card_le_thirteen`
  and its `high24_clique_card_le_fifteen` corollary.
- `High24Packing.lean`: constructs `MinimalCliqueBounds20` using the proved
  high24 bound and four explicit lower-threshold hypotheses, then exports the
  corresponding original-edge packing theorem.
- `Bounds/EdgeCounting.lean`: exact incidence counting, with one duplicate
  per internal edge, and clique bounds from selected incidence degrees.
- `Bounds/High23Local.lean`: a high23 edge has degree-four endpoints, lies in
  no triangle, and lies in at most one four-cycle.
- `Bounds/High23Support.lean`: root-neighbour types have size at most two;
  double types sharing a selected root label belong to the same vertex.
- `Bounds/High23Outer.lean`: at most two clique edges lie outside a root's
  closed neighbourhood when it has at least three selected incident edges;
  selected incidence degrees at most three imply a clique bound of 14.
- `Bounds/High23Four.lean`: a four-edge root star has at most six singleton-type
  edges and at most four multiple-type edges meeting its neighbourhood.
- `Bounds/High23.lean`: combines the support-degree cases to prove
  `high23_clique_card_le_sixteen` from the original degree bound alone.
- `High23Packing.lean`: supplies both high23 and high24 to the unchanged minimal
  record, leaving only high20, high21, and high22 explicit in the packing wrapper.
- `Bounds/High22Local.lean`: degree-four endpoints, no triangle on a selected
  high22 edge, and at most two internal cover edges and four-cycles.
- `Bounds/RootCounting.lean`: a singleton-type selected edge restricts all
  selected tips to at most six vertices; generic root and outer incidence counts.
- `Bounds/High22Support.lean`: proves the root-label two-loss budget and bounds
  multiple-type vertices, including the triple-type case.
- `Bounds/High22RootFour.lean`: a clique containing a four-edge root star has
  at most 17 edges, by selected-tip counts and original-degree saturation.
- `Bounds/High22Heavy.lean`: for a three-edge root, at most three vertices meet
  two selected root labels; at most six selected edges lie outside its closed
  neighbourhood, with precise equality consequences.
- `Bounds/High22Subcubic.lean`: excludes the equality case to prove high22 ≤17
  when selected support degrees are at most three. This theorem retains the
  high22 hypothesis; the new threshold-free bound 18 is proved separately in `SubcubicEighteen`.
- `Bounds/High22.lean`: combines the two support-degree branches to prove
  `high22_clique_card_le_seventeen` under exactly the requested assumptions.
- `High22Packing.lean`: supplies high22 to the preserved constructor and exports
  packing with only high20 and high21 as explicit structural assumptions.

- `Bounds/High21Local` and `Bounds/High21Support`: local and root-label three-loss budgets.
- `Bounds/SubcubicEighteen`: threshold-free bound 18 for selected support degrees at most three.
- `Bounds/High21LargeType`: bound 18 when a four-edge root has a type of size at least three.
- `Bounds/DegreeTwoClique`: bound four with internal original degree at most two and a selected bipartition.
- `Bounds/High21Double`: at most four fully selected double tips.
- `Bounds/High21RootFour`: bound 18 for every four-edge root.
- `Bounds/High21`: universal `high21_clique_card_le_eighteen`.
- `High21Packing`: supplies high21 and exports packing with only high20 explicit.

`Packing.lean` extends the conditional result to every candidate subset and
states it in terms of original edges. It passed the full build and axiom audit.
Both threshold records and all 26 earlier mathematical source modules
are unchanged. No claim is made that a maximum-degree-four original graph has
yet been shown to satisfy either threshold record without the remaining
high20 hypothesis. The original record's stronger high24 bound 7 is still open.

## Pinned environment

- Lean: `leanprover/lean4:v4.35.0-rc4`
- Lean compiler commit: `c29b6dda4f7c20e3eeaa717c4e565663c5cfa364`
- mathlib: `49fd9dee36e7bbf345fe7981d2de6aeeb591f75b`
- Dependency lockfile: `lake-manifest.json`

The Windows compiler was downloaded from the official Lean release and verified
against SHA-256 `549c0d70f58346be61d9353b5ff8b3d89430b49184d1833244ba2f3afca3dabd`.
It lives beside this project in `../.tools/lean-4.35.0-rc4-windows`; `lean.ps1`
uses it when available, otherwise it uses Lake from PATH. Compiler binaries,
dependency checkouts, and caches are excluded from the source archive.

## Reproduce

In this project's Windows PowerShell directory:

```powershell
.\lean.ps1 build
.\lean.ps1 env lean StrongEdge/Audit.lean
```

With Lean/elan already installed on another system:

```sh
lake exe cache get Mathlib.Combinatorics.SimpleGraph.Clique Mathlib.Combinatorics.SimpleGraph.LineGraph Mathlib.Tactic.ByContra Mathlib.Tactic.Linarith Mathlib.Tactic.Tauto Mathlib.Algebra.Order.BigOperators.Group.Finset
lake build
lake env lean StrongEdge/Audit.lean
```

Keep the supplied lockfile; `lake update` is not needed for an ordinary rebuild.
The first build may need network access to materialize locked dependencies.

## Checked endpoint

The current endpoint is
`StrongEdge.induced_matching_packing20_of_high20`.
It takes the original degree bound `hΔ` and exactly one explicit clique-bound
parameter, with the meanings in the table below. It constructs the old `hb`
record by supplying `high21_clique_card_le_eighteen`, `high22_clique_card_le_seventeen`, `high23_clique_card_le_sixteen`, and
`high24_clique_card_le_fifteen` automatically and calls the
preserved `StrongEdge.induced_matching_packing20_of_minimal_clique_bounds`:

```lean
(hΔ : ∀ x, G.degree x ≤ 4)
(hb : MinimalCliqueBounds20 (conflictGraph G)) (F : Finset G.edgeSet) :
  ∃ M ⊆ F, IsInducedMatching G (M : Set G.edgeSet) ∧ F.card ≤ 20 * M.card
```

The finite-vertex and decidability instances are shown in full in the axiom log.
The old wrapper still takes `hb`; the new wrapper discharges its high21, high22, high23,
and high24 fields and retains high20 explicitly. The old
`induced_matching_packing20_of_thresholds` is also preserved and audited.
The private-clique, degree-exchange and double-counting proofs have no such
structural premises. Empty graphs and empty candidate sets require no exception.

The source scan found no `sorry`, `admit`, `axiom`, `constant`, `unsafe`, or
`native_decide` tokens in the 37 project Lean files. The axiom audit, rather than that textual
scan alone, checks the exported proof dependencies. Source/configuration SHA-256
fingerprints are saved in `verification/high21-source-sha256.json`.
Earlier source manifests are retained as historical snapshots.

## Still required

For every clique `Q` in the **full** conflict graph, `MinimalCliqueBounds20`
requires the following five facts. The last four have now been proved universally.

| Field | Lower bound on every member's full conflict degree | Required bound on `Q.card` | Status |
|---|---:|---:|---|
| `high20` | 20 | 19 | Open |
| `high21` | 21 | 18 | Proved |
| `high22` | 22 | 17 | Proved |
| `high23` | 23 | 16 | Proved |
| `high24` | 24 | 15 | Proved, with stronger bound 13 |

Next, formalise `high20`.
Discharging the last open field yields the unconditional theorem through the
new wrapper. The original
record additionally includes maximum degree 24 (now proved for these conflict
graphs) and uses the stronger degree-24 clique bound 7. The 19.5 strengthening
remains a later, separate goal.

The current result is conditional; it proves neither unconditional 20-packing
nor integer strong-edge 20-colourability. The input handoff is retained in
`LEAN_20_PACKING_HANDOFF.md`; its original uncompiled-starter descriptions are
historical. This README and the saved build/audit logs describe the current code.

## Mathematical source

[Research proof at the supplied commit](https://github.com/congyuemao/strong-edge-colouring-research/blob/3a95c4a9c44475196c42b6eab4749c487d15d59b/research/packing_private_cliques.md).

[High23 proof at the same commit](https://github.com/congyuemao/strong-edge-colouring-research/blob/3a95c4a9c44475196c42b6eab4749c487d15d59b/research/high_conflict_23_improved.md).
This implementation uses a uniform outer-edge bound of two to obtain the
required 16; the optional strengthening to 15 is not exported.

[High22 threshold proof at the same commit](https://github.com/congyuemao/strong-edge-colouring-research/blob/3a95c4a9c44475196c42b6eab4749c487d15d59b/research/high_conflict_thresholds.md).
The high22 implementation uses shorter selected-tip and equality arguments
described in `HIGH22_HANDOFF.md`. The optional high22 bound 16 is not exported.

The high21 proof uses the same pinned threshold manuscript and shorter counting
arguments documented in `C5_HIGH21_VERIFIED_HANDOFF.md`. Run
`python verification/finalize-high21.py` after the Lean commands to check saved
evidence and package the source-only checkpoint. This script does not prove mathematics.
