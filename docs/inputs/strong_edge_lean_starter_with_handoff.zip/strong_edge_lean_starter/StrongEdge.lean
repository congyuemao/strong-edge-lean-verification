import StrongEdge.Basic
