# Strong edge-colouring: Lean 4 starter

## Scope and verification status

This is a **candidate Lean 4 formalisation**, not a completed or certified
formal proof of the 20-packing theorem. It was prepared on 9 October 2026.

The current execution environment has no `lean`, `lake` or `elan` binary and
cannot download Lean over the network. Consequently, the Lean file has **not
been typechecked**. It has no intentional `sorry` or new axioms, but those
properties alone do not establish that it compiles.

The code aims to establish:

1. `StrongConflict` uses the entire original edge set, including witness
   edges outside the selected candidates.
2. `conflictGraph` and `candidateConflictGraph` represent the strong edge
   conflict relation and its induced restriction.
3. `private_centre` and `private_isClique` express the private-neighbourhood
   exchange argument in an arbitrary finite graph.
4. `twenty_packing_arithmetic` is only the arithmetic final step, **not**
   the global counting theorem.

**Remaining for the desired theorem:** select a maximum independent set with
minimum degree sum; formalise the degree monotonicity exchange; formalise the
incidence double-counting inequality; formalise the strong-clique threshold
lemmas for maximum original degree four; connect all lemmas and obtain the
universal `∀ F` result. These are not yet proved here.

## Build steps

Install elan from https://lean-lang.org/install and use a terminal in this
folder:

```bash
lake update
lake exe cache get
lake env lean StrongEdge/Basic.lean
lake build
```

The `lean-toolchain` and mathlib dependency reference are pinned to the
versions observed on 9 October 2026. If a type error is reported, treat it
as an **unverified draft issue** and fix it before citing any theorem as
formalised.

To check for proof gaps, search every `.lean` file for `sorry`, `admit`,
`axiom`, `unsafe`, and `native_decide`. Passing a text search is not a
substitute for `lake build`.

## Mathematical source

https://github.com/congyuemao/strong-edge-colouring-research/blob/codex/research-archive/research/packing_private_cliques.md
