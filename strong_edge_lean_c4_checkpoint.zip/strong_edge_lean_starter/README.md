# Strong-edge packing: Lean formalisation

C4 is complete: every original edge of a finite simple graph of maximum degree
four has full conflict degree at most 24. The project also contains verified
local structure lemmas for equality at 24, and the earlier private-neighbourhood
exchange and double-counting proofs. The unconditional 20-packing theorem is
**not yet proved**: five clique-size bounds remain open in this formalisation.

Verified on 9 October 2026: the full build passed (1,127 jobs) and all 38 audited
theorems use only `propext`, `Classical.choice`, and `Quot.sound`. No proof gaps
or custom axioms occur in these dependency closures. Current evidence is in
`verification/next-stage-build.log` and `verification/next-stage-axioms.log`.
The previous 1,124-job build and 13-theorem audit are preserved in the original
logs. See [the stage report](verification/NEXT_STAGE_REPORT.md) for the exact
25 new theorem names, assumptions, checks, and remaining work.

## Verified mathematical core

- `Basic.lean`: all-original-edge conflicts and the private-clique exchange.
- `Conflict.lean`: independence/induced-matching equivalence and the inequality
  from candidate conflict degree to full conflict degree.
- `PrivateExchange.lean`: existence of a maximum independent set with minimum
  ambient degree sum, and the degree-monotonicity exchange.
- `DoubleCount.lean`: closed-neighbourhood incidence counting and
  `2 * Fintype.card W ≤ ∑ v ∈ M, (degree v + 1 + privateCard v)`;
  an explicit local bound implies packing, including the conditional 20 bound.
- `Tests.lean`: in the path 0-1-2-3 the outer edges conflict; after removing 1-2
  they do not. Restricting candidates retains the original conflict.
- `Bounds/ConflictDegree.lean`: an incidence cover proves
  `conflict_degree_le_24` directly from the original maximum-degree-four bound.
- `Bounds/ConflictRigidity.lean`: equality at 24 forces both endpoints and their
  six other neighbours to have degree four; those six vertices are independent,
  neither endpoint lies in a triangle, and the fixed edge lies in no four-cycle.
- `MinimalPacking.lean`: a separate, weaker interface suffices for 20-packing;
  the degree-24 clique bound need only be 15. The new original-edge wrapper
  supplies C4 automatically and retains the five clique bounds explicitly.

`Packing.lean` extends the conditional result to every candidate subset and
states it in terms of original edges. It passed the full build and axiom audit.
The old `CliqueThresholds20` definition and all six earlier core source files
are unchanged. No claim is made that a maximum-degree-four original graph has
yet been shown to satisfy either that record or the new `MinimalCliqueBounds20`.

## Pinned environment

- Lean: `leanprover/lean4:v4.35.0-rc4`
- Lean compiler commit: `c29b6dda4f7c20e3eeaa717c4e565663c5cfa364`
- mathlib: `49fd9dee36e7bbf345fe7981d2de6aeeb591f75b`
- Dependency lockfile: `lake-manifest.json`

The Windows compiler was downloaded from the official Lean release and verified
against SHA-256 `549c0d70f58346be61d9353b5ff8b3d89430b49184d1833244ba2f3afca3dabd`.
It lives beside this project in `../.tools/lean-4.35.0-rc4-windows`; `lean.ps1`
uses it when available, otherwise it uses Lake from PATH. Compiler binaries,
dependency checkouts, and caches are excluded from the source archive.

## Reproduce

In this project's Windows PowerShell directory:

```powershell
.\lean.ps1 build
.\lean.ps1 env lean StrongEdge/Audit.lean
```

With Lean/elan already installed on another system:

```sh
lake exe cache get Mathlib.Combinatorics.SimpleGraph.Clique Mathlib.Combinatorics.SimpleGraph.LineGraph Mathlib.Tactic.ByContra Mathlib.Tactic.Linarith Mathlib.Tactic.Tauto Mathlib.Algebra.Order.BigOperators.Group.Finset
lake build
lake env lean StrongEdge/Audit.lean
```

Keep the supplied lockfile; `lake update` is not needed for an ordinary rebuild.
The first build may need network access to materialize locked dependencies.

## Checked endpoint

The new `StrongEdge.induced_matching_packing20_of_minimal_clique_bounds` proves

```lean
(hΔ : ∀ x, G.degree x ≤ 4)
(hb : MinimalCliqueBounds20 (conflictGraph G)) (F : Finset G.edgeSet) :
  ∃ M ⊆ F, IsInducedMatching G (M : Set G.edgeSet) ∧ F.card ≤ 20 * M.card
```

The finite-vertex and decidability instances are shown in full in the axiom log.
The `hb` premise remains undischarged for arbitrary original maximum-degree-four
graphs. It is an explicit theorem parameter. The old
`induced_matching_packing20_of_thresholds` is also preserved and audited.
The private-clique, degree-exchange and double-counting proofs have no such
structural premises. Empty graphs and empty candidate sets require no exception.

The source scan found no `sorry`, `admit`, `axiom`, `constant`, `unsafe`, or
`native_decide` tokens in the eleven project Lean files. The axiom audit, rather than that textual
scan alone, checks the exported proof dependencies. Source/configuration SHA-256
fingerprints are saved in `verification/next-stage-source-sha256.json`.
The original `verification/source-sha256.json` is retained as the prior snapshot.

## Still required

For every clique `Q` in the **full** conflict graph, `MinimalCliqueBounds20`
requires the following five facts. None has yet been proved universally here.

| Field | Lower bound on every member's full conflict degree | Required bound on `Q.card` |
|---|---:|---:|
| `high20` | 20 | 19 |
| `high21` | 21 | 18 |
| `high22` | 22 | 17 |
| `high23` | 23 | 16 |
| `high24` | 24 | 15 |

Next, use the verified equality structure to bound degree-24 cliques, then
formalise the remaining high-conflict clique bounds. Discharging all five
fields yields the unconditional theorem through the new wrapper. The original
record additionally includes maximum degree 24 (now proved for these conflict
graphs) and uses the stronger degree-24 clique bound 7. The 19.5 strengthening
remains a later, separate goal.

The current result is conditional; it proves neither unconditional 20-packing
nor integer strong-edge 20-colourability. The input handoff is retained in
`LEAN_20_PACKING_HANDOFF.md`; its original uncompiled-starter descriptions are
historical. This README and the saved build/audit logs describe the current code.

## Mathematical source

[Research proof at the supplied commit](https://github.com/congyuemao/strong-edge-colouring-research/blob/3a95c4a9c44475196c42b6eab4749c487d15d59b/research/packing_private_cliques.md).
