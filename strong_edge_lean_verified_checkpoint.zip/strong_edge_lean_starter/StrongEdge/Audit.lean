module

public import StrongEdge

#print axioms StrongEdge.strongConflict_symm
#print axioms StrongEdge.candidate_independent_iff
#print axioms StrongEdge.candidate_degree_le_full
#print axioms StrongEdge.private_isClique
#print axioms StrongEdge.optimal_exists
#print axioms StrongEdge.private_degree_mono
#print axioms StrongEdge.private_double_count
#print axioms StrongEdge.packing_of_local_bound
#print axioms StrongEdge.packing20_of_thresholds
#print axioms StrongEdge.subset_packing20_of_thresholds
#print axioms StrongEdge.induced_matching_packing20_of_thresholds
#print axioms StrongEdge.Tests.path_outer_edges_conflict
#print axioms StrongEdge.Tests.separated_outer_edges_do_not_conflict

#check StrongEdge.packing20_of_thresholds
#check StrongEdge.induced_matching_packing20_of_thresholds
